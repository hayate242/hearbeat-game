﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Player : MonoBehaviour {

    // Set player velocity
    public int playerVelocity = 1;
    Rigidbody2D playerBody;
	float playerRadius;

	// check boundary - don"t let player move out of bound
	Vector2 leftBound;
	Vector2 rightBound;

	//id finger
	private int finId1 = -1;
	private int finId2 = -1;

	//for debugging purposes
	Text touchStatus;

	// Use this for initialization
	void Start () {
        // Get player rigidbody component
        playerBody = GetComponent<Rigidbody2D>();

		// Get player collider radius
		playerRadius = GetComponent<CircleCollider2D>().radius;

		// init bounds
		leftBound = Camera.main.ViewportToWorldPoint(new Vector2(0.0f, 0.0f));
		rightBound = Camera.main.ViewportToWorldPoint(new Vector2(1.0f, 0.0f));

		//init multitouch
		Input.multiTouchEnabled = true;

		touchStatus = GameObject.Find ("touchstatus").GetComponent<Text> ();
		touchStatus.text = "test";
		Debug.Log (touchStatus.text);
	}
	
	// Update is called once per frame
	void Update () {
		//check count of touch
		if (Input.touchCount > 0) {
			foreach (Touch touch in Input.touches) {
				// For the left half screen
				if (touch.phase == TouchPhase.Began && touch.position.x <= Screen.width/2 && finId1 == -1) {
					//move left
					touchStatus.text = "move left";
					playerBody.velocity = Vector2.zero;
					playerBody.AddForce(new Vector2(playerVelocity * -1, 0));
					finId1 = touch.fingerId; // store id finger
				}

				// For the right half screen
				if (touch.phase == TouchPhase.Began && touch.position.x > Screen.width/2 && finId2 == -1) {
					//move right
					touchStatus.text = "move right";
					playerBody.velocity = Vector2.zero;
					playerBody.AddForce(new Vector2(playerVelocity, 0));
					finId2 = touch.fingerId; // store id finger
				}

				if (touch.phase == TouchPhase.Ended) {
					if (touch.fingerId == finId1) {
						finId1 = -1;
					} else if (touch.fingerId == finId2) {
						finId2 = -1;
					}
				}
			}
		}

        // Move player
        if (Input.GetKeyUp(KeyCode.LeftArrow)) {
            playerBody.velocity = Vector2.zero;
            playerBody.AddForce(new Vector2(playerVelocity * -1, 0));
        } else if (Input.GetKeyUp(KeyCode.RightArrow)) {
            playerBody.velocity = Vector2.zero;
            playerBody.AddForce(new Vector2(playerVelocity, 0));
        } else {
            // Just in case the drag doesn't work out
            //Vector2 slowDown = playerBody.velocity;
            //slowDown.x = playerBody.velocity.x * 0.9F;
            //playerBody.velocity = slowDown;
        }

		// Bound player inside the screen
		if (transform.position.x  < leftBound.x) {
			playerBody.velocity = Vector2.zero;
			transform.position = new Vector2 (leftBound.x, transform.position.y);
		} else if (transform.position.x > rightBound.x) {
			playerBody.velocity = Vector2.zero;
			transform.position = new Vector2 (rightBound.x, transform.position.y);
		}

		// If player collides with an object
	}

	void OnCollisionEnter2D (Collision2D coll){
		if (coll.gameObject.tag == "Obstacles") {
			Destroy (gameObject);
		}
	}
}
