﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameState : MonoBehaviour {

	float startTime;
	//Total game score
	public int gameScore;
	public bool endGame;
	public GameObject GameOver;

	//Get score text component
	Text scoreText;

	void GameStarts(){
		startTime = Time.time;
		scoreText = GameObject.Find("ScoreText").GetComponent<Text>();
		scoreText.text = "Score : 0";
		endGame = false;
	}

	float CalculateScore(){
		return (Time.time - startTime);
	}

	// Use this for initialization
	void Start () {
		GameStarts ();

	}
	
	// Update is called once per frame
	void Update () {
		// if the game is not over, calculate score etc
		if (!endGame) {
			gameScore = (int)CalculateScore ();
			scoreText.text = "Score : " + gameScore;

			//show game over once
			if (!GameObject.Find ("PlayerCircle")) {
				endGame = true;
				GameObject GameOverText = (GameObject)Instantiate (GameOver);
				GameObject Canvas = GameObject.Find ("Canvas");
				GameOverText.transform.SetParent (Canvas.transform);
				GameOverText.transform.localPosition = new Vector2(0,0);
				GameOverText.transform.localRotation = Quaternion.identity;
			}
		} else {
			// restart game using tap
			if (Input.touchCount > 0) {
				GameStarts ();
			}
		}
	}
}
