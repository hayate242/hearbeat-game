﻿using UnityEngine;
using System.Collections;

public class UIObjects : MonoBehaviour {

	void OnGUI(){
		//Write here
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
