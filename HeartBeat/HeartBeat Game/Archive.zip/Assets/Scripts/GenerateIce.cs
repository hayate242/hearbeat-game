﻿using UnityEngine;
using System.Collections;

public class GenerateIce : MonoBehaviour {

    public GameObject ice;

	//check game status
	bool endGame;

    // Initialize ice position and rotation
    Vector2 icePosition;
    Quaternion iceRot;

	// Ice's velocity & rotation
	Vector2 iceVelocity;
	float rotDegree = (Mathf.PI / 3)*-1;

	public float speed = 2.0f;

	// Use this for initialization
	void Start () {
        InvokeRepeating("MakeIce", 1.0f, 0.2f);
	}

    void MakeIce() {
        // Randomize position - outside the viewport
        float iceX = Random.Range(-0.5f, 1.0f);

        // Set position and rotation
        icePosition = new Vector2(iceX, 1.1f);
        iceRot = Quaternion.Euler(new Vector3(0, 0, 30));

        // transform viewport coordinates to world point
        icePosition = Camera.main.ViewportToWorldPoint(icePosition);

		speed += 0.01f;
		print (speed);

        // Spawn ice!
		GameObject InstantIce = (GameObject)Instantiate(ice, icePosition, iceRot);

		Rigidbody2D IceRigid = InstantIce.GetComponent<Rigidbody2D> ();

		// Calculate ice's velocity using trig functions
		iceVelocity = new Vector2(Mathf.Cos(rotDegree)*speed, Mathf.Sin(rotDegree)*speed);

		IceRigid.velocity = iceVelocity;
    }
	
	// Update is called once per frame
	void Update () {
		// take endgame from game state script
		endGame = GameObject.Find("GameState").GetComponent<GameState>().endGame;
		Debug.Log (endGame);
		if (endGame) {
			CancelInvoke ("MakeIce");
			print ("ohh");
		
		}
	}
}
