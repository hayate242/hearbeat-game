﻿using UnityEngine;
using System.Collections;

public class Ice : MonoBehaviour {
    // Ice explosion prefab
    public GameObject explosionPrefab;

	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frameß
	void Update () {
        // get position
        Vector2 viewPosition = Camera.main.WorldToViewportPoint(transform.position);

        if (viewPosition.y < 0)
            Destroy(gameObject);
	}

    void OnCollisionEnter2D (Collision2D coll) {
        if (coll.gameObject.tag == "Floor") {
            Object explodeIce = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            Destroy(gameObject, 0.1f);
        }
    }

    void OnTriggerEnter2D (Collider2D coll) {
        Debug.Log(coll.gameObject.tag);
        if (coll.gameObject.tag == "FloorTrigger") {
            Object explodeIce = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            Destroy(gameObject, 0.1f);
            Destroy(explodeIce, 2.1f);
        }
    }
}
