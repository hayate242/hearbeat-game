﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {

    // Set player velocity
    public int playerVelocity = 1;
    Rigidbody2D playerBody;
	float playerRadius;

	// check boundary - don"t let player move out of bound
	Vector2 leftBound;
	Vector2 rightBound;

	// Use this for initialization
	void Start () {
        // Get player rigidbody component
        playerBody = GetComponent<Rigidbody2D>();

		// Get player collider radius
		playerRadius = GetComponent<CircleCollider2D>().radius;

		// init bounds
		leftBound = Camera.main.ViewportToWorldPoint(new Vector2(0.0f, 0.0f));
		rightBound = Camera.main.ViewportToWorldPoint(new Vector2(1.0f, 0.0f));
	}
	
	// Update is called once per frame
	void Update () {
        // Move player
        if (Input.GetKeyUp(KeyCode.LeftArrow)) {
            playerBody.velocity = Vector2.zero;
            playerBody.AddForce(new Vector2(playerVelocity * -1, 0));
        } else if (Input.GetKeyUp(KeyCode.RightArrow)) {
            playerBody.velocity = Vector2.zero;
            playerBody.AddForce(new Vector2(playerVelocity, 0));
        } else {
            // Just in case the drag doesn't work out
            //Vector2 slowDown = playerBody.velocity;
            //slowDown.x = playerBody.velocity.x * 0.9F;
            //playerBody.velocity = slowDown;
        }

		// Bound player inside the screen
		if (transform.position.x  < leftBound.x) {
			playerBody.velocity = Vector2.zero;
			transform.position = new Vector2 (leftBound.x, transform.position.y);
		} else if (transform.position.x > rightBound.x) {
			playerBody.velocity = Vector2.zero;
			transform.position = new Vector2 (rightBound.x, transform.position.y);
		}

		// If player collides with an object
	}

	void OnCollisionEnter2D (Collision2D coll){
		if (coll.gameObject.tag == "Obstacles") {
			Destroy (gameObject);
		}
	}
}
