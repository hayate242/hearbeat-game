﻿using UnityEngine;
using System.Collections;

public class Generatecar : MonoBehaviour {

	public GameObject ice;

	// Initialize ice position and rotation
	Vector2 icePosition;
	Quaternion iceRot;

	// Ice's velocity & rotation
	Vector2 iceVelocity;
	//float rotDegree = (Mathf.PI / 3)*-1;

	public float speed = 2.0f;

	// Use this for initialization
	void Start () {
		InvokeRepeating("MakeIce", 1.0f, 1.5f);
	}

	void MakeIce() {
		// Randomize position - outside the viewport
		float iceX = Random.Range(0.1f, 0.95f);

		// Set position and rotation
		icePosition = new Vector2(iceX, 1.1f);
		iceRot = Quaternion.Euler(new Vector3(0, 0, -90));

		// transform viewport coordinates to world point
		icePosition = Camera.main.ViewportToWorldPoint(icePosition);

		speed += 0.01f;
		print (speed);

		// Spawn ice!
		GameObject InstantIce = (GameObject)Instantiate(ice, icePosition, iceRot);

		Rigidbody2D IceRigid = InstantIce.GetComponent<Rigidbody2D> ();

		// Calculate ice's velocity using trig functions
		iceVelocity = new Vector2(0, -1 * speed);

		IceRigid.velocity = iceVelocity;

		print (IceRigid.velocity);
	}

	// Update is called once per frame
	void Update () {

	}
}
