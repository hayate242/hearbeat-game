﻿using UnityEngine;

public class Score : MonoBehaviour
{
	// スコアを表示するGUIText
	public GUIText scoreGUIText;

	// ハイスコアを表示するGUIText
	public GUIText highScoreGUIText;

	// スコア
	public int score = 0;

	// ハイスコア
	private int highScore;

	// PlayerPrefsで保存するためのキー
	private string highScoreKey = "highScore";

	private Manager manager;

	int StartTime;
	bool Startst; 
	bool touched;
	bool firstTouch;

	void Start ()
	{
		Initialize ();

		// Managerコンポーネントをシーン内から探して取得する
		manager = FindObjectOfType<Manager>();

		Startst = false;
		touched = false;
		firstTouch = true;
	}
	void GameStart ()
	{
		//Starting time
		StartTime = (int)Time.time;
		Startst = true;
	}

	void Update ()
	{
		if (Input.touchCount > 0 && firstTouch  == true) {
			touched = true;
			firstTouch = false;
		}
		//Debug.Log (touched);
		// ゲーム中で、画面が押されたらtrueを返す。
		if (manager.IsPlaying () == true && touched == true) {
			GameStart ();
			touched = false;
		}
		if (manager.IsPlaying () == false) {
			Initialize ();
		}

		//Debug.Log (manager.IsPlaying ());
		// スコアがハイスコアより大きければ
		if (highScore < score) {
			highScore = score;
		}
		//現在位のスコアを計算
		if (Startst == true) {
			score = (int)Time.time - StartTime;
		}

		//Debug.Log (StartTime);
		// スコア・ハイスコアを表示する
		scoreGUIText.text = score.ToString ();
		highScoreGUIText.text = "HighScore : " + highScore.ToString ();
	}

	// ゲーム開始前の状態に戻す
	private void Initialize ()
	{
		// スコアを0に戻す
		score = 0;
		StartTime = 0;
		touched = false;
		firstTouch = true;

		// ハイスコアを取得する。保存されてなければ0を取得する。
		highScore = PlayerPrefs.GetInt (highScoreKey, 0);

		//Startstatus = false
		Startst = false;
	}

//	// ポイントの追加
//	public void AddPoint (int point)
//	{
//		score = score + point;
//	}

	// ハイスコアの保存
	public void Save ()
	{
		// ハイスコアを保存する
		PlayerPrefs.SetInt (highScoreKey, highScore);
		PlayerPrefs.Save ();

		// ゲーム開始前の状態に戻す
		Initialize ();
	}

	public int getScore(){
		return score;
	}


}
